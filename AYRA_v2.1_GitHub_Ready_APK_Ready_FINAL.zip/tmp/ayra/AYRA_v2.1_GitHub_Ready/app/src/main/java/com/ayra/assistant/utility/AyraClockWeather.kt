package com.ayra.assistant.utility

import android.location.Location
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object AyraClockWeather {
    fun time(now: Date = Date()): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
    fun date(now: Date = Date()): String = SimpleDateFormat("EEE, dd MMM", Locale.getDefault()).format(now)

    data class Weather(val temperature: String, val condition: String, val location: String)

    fun interface WeatherProvider {
        fun getWeather(location: Location?, callback: (Weather?, Throwable?) -> Unit)
    }
}

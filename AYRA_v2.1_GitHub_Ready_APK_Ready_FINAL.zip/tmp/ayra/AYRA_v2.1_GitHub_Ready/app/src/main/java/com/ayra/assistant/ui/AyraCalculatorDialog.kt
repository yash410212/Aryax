package com.ayra.assistant.ui

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.ayra.assistant.tools.CalculatorEngine

/** Compact calculator matching the supplied reference direction: dark body, rounded keys, orange action rail. */
class AyraCalculatorDialog(context: Context) : Dialog(context) {
    private lateinit var display: TextView
    private var expression = ""

    override fun onCreate(state: android.os.Bundle?) {
        super.onCreate(state)
        window?.setBackgroundDrawableResource(android.R.color.transparent)
        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            background = bg(Color.rgb(24, 27, 31), 24)
        }
        display = TextView(context).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            text = "0"
            setTextColor(Color.WHITE)
            textSize = 34f
            setPadding(10, 10, 10, 14)
            minHeight = 92
            background = bg(Color.rgb(10, 12, 15), 18)
        }
        root.addView(display, LinearLayout.LayoutParams(-1, 100))

        val grid = GridLayout(context).apply { columnCount = 4; rowCount = 5; setPadding(0, 12, 0, 0) }
        val keys = arrayOf("AC","DEL","%","÷","7","8","9","×","4","5","6","−","1","2","3","+","0",".","(")
        keys.forEachIndexed { index, key ->
            val b = Button(context).apply {
                text = key; textSize = 17f; isAllCaps = false; setTextColor(if(index%4==3 || key=="=") Color.rgb(255,180,90) else Color.WHITE)
                background = bg(Color.rgb(42, 46, 52), 18)
                setOnClickListener { press(key) }
            }
            val lp = GridLayout.LayoutParams().apply { width=0; height=64; columnSpec=GridLayout.spec(index%4,1f); rowSpec=GridLayout.spec(index/4); setMargins(4,4,4,4) }
            grid.addView(b, lp)
        }
        val equals = Button(context).apply {
            text="="; textSize=20f; setTextColor(Color.WHITE); background=bg(Color.rgb(245,128,24),18); setOnClickListener { evaluate() }
        }
        val eqLp=GridLayout.LayoutParams().apply{width=0;height=64;columnSpec=GridLayout.spec(3,1f);rowSpec=GridLayout.spec(4);setMargins(4,4,4,4)}
        grid.addView(equals, eqLp)
        root.addView(grid, LinearLayout.LayoutParams(-1, 5*72))
        setContentView(root)
        window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun press(key:String){
        when(key){
            "AC" -> expression=""
            "DEL" -> if(expression.isNotEmpty()) expression=expression.dropLast(1)
            "%" -> if(expression.isNotEmpty()) expression += "/100"
            else -> expression += key
        }
        display.text=if(expression.isBlank()) "0" else expression
    }
    private fun evaluate(){ expression=CalculatorEngine.evaluate(expression); display.text=expression }
    private fun bg(color:Int,radius:Int)=GradientDrawable().apply{setColor(color);cornerRadius=radius*context.resources.displayMetrics.density}
}

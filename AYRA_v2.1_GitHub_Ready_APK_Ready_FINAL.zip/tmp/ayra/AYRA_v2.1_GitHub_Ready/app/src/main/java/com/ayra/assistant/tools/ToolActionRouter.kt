package com.ayra.assistant.tools

import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.provider.Settings

/**
 * Central routing for AYRA's quick controls. Android 11+ restricts silent
 * Wi‑Fi/hotspot changes, so restricted actions open the relevant system panel
 * instead of faking a successful toggle.
 */
object ToolActionRouter {
    fun run(context: Context, action: Action) {
        val intent = when (action) {
            Action.WIFI -> Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
            Action.BLUETOOTH -> Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            Action.HOTSPOT -> Intent(Settings.ACTION_WIRELESS_SETTINGS)
            Action.BATTERY -> Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
            Action.NETWORK -> Intent(Settings.ACTION_WIRELESS_SETTINGS)
            Action.CALCULATOR, Action.TIME, Action.WEATHER -> null
        }
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try { context.startActivity(intent) } catch (_: Exception) {
                context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
    }

    enum class Action { WIFI, BLUETOOTH, HOTSPOT, BATTERY, NETWORK, CALCULATOR, TIME, WEATHER }
}

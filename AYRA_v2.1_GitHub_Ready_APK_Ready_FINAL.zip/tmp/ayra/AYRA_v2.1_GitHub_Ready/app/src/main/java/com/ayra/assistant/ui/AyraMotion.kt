package com.ayra.assistant.ui

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.view.View
import android.view.animation.DecelerateInterpolator
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

object AyraMotion {
    private const val FAST = 180L
    private const val NORMAL = 240L

    fun press(view: View) {
        view.animate().cancel()
        view.animate().scaleX(.97f).scaleY(.97f).setDuration(90L)
            .withEndAction {
                view.animate().scaleX(1f).scaleY(1f).setDuration(FAST)
                    .setInterpolator(DecelerateInterpolator()).start()
            }.start()
    }

    fun reveal(view: View, delay: Long = 0L) {
        view.animate().cancel()
        view.alpha = 0f; view.translationY = 18f
        view.animate().alpha(1f).translationY(0f).setStartDelay(delay)
            .setDuration(NORMAL).setInterpolator(DecelerateInterpolator()).start()
    }

    fun crossfade(oldView: View, newView: View) {
        if (oldView === newView) return
        oldView.animate().cancel(); newView.animate().cancel()
        newView.alpha = 0f; newView.visibility = View.VISIBLE
        oldView.animate().alpha(0f).setDuration(FAST).withEndAction {
            oldView.visibility = View.GONE
            newView.animate().alpha(1f).setDuration(FAST).start()
        }.start()
    }

    fun applyBottomInset(view: View) {
        val initialBottom = view.paddingBottom
        ViewCompat.setOnApplyWindowInsetsListener(view) { v, insets ->
            val bottom = insets.getInsets(WindowInsetsCompat.Type.systemBars()).bottom
            v.setPadding(v.paddingLeft, v.paddingTop, v.paddingRight, initialBottom + bottom)
            insets
        }
        ViewCompat.requestApplyInsets(view)
    }
}

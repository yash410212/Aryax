package com.ayra.assistant.tools

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Thread-safe formatting helpers: creates short-lived formatters per call. */
object AyraUtilityState {
    fun currentTime(now: Date = Date()): String = SimpleDateFormat("h:mm a", Locale.getDefault()).format(now)
    fun currentDate(now: Date = Date()): String = SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(now)
}

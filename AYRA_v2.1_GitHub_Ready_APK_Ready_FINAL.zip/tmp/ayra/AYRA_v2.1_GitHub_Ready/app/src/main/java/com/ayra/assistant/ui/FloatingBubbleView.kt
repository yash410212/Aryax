package com.ayra.assistant.ui

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.SweepGradient
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

/** Lightweight animated AYRA orb. Avoids per-frame random/allocation-heavy work. */
class FloatingBubbleView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    enum class State { IDLE, LISTENING, PROCESSING }

    var state: State = State.IDLE
        set(value) { if (field != value) { field = value; onStateChanged() } }

    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val discPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(235, 12, 14, 20) }
    private val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
        strokeCap = Paint.Cap.ROUND
    }
    private val matrix = Matrix()
    private val colors = intArrayOf(
        Color.parseColor("#4285F4"), Color.parseColor("#9B72CB"),
        Color.parseColor("#D96570"), Color.parseColor("#4285F4")
    )
    private var pulsePhase = 0f
    private var rotation = 0f
    private var waveAmplitude = 0f
    private var pulseAnimator: ValueAnimator? = null
    private var rotateAnimator: ValueAnimator? = null
    private var ampAnimator: ValueAnimator? = null
    private var sweep: SweepGradient? = null
    private var glow: RadialGradient? = null
    private var lastRadius = -1f

    init { isFocusable = false; startAnimators() }

    private fun startAnimators() {
        pulseAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1600L; repeatMode = ValueAnimator.REVERSE; repeatCount = ValueAnimator.INFINITE
            addUpdateListener { pulsePhase = it.animatedValue as Float; invalidate() }; start()
        }
        rotateAnimator = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 6000L; repeatCount = ValueAnimator.INFINITE
            addUpdateListener { rotation = it.animatedValue as Float; invalidate() }; start()
        }
    }

    private fun onStateChanged() {
        ampAnimator?.cancel()
        val target = if (state == State.LISTENING) 1f else 0f
        ampAnimator = ValueAnimator.ofFloat(waveAmplitude, target).apply {
            duration = 220L
            addUpdateListener { waveAmplitude = it.animatedValue as Float; invalidate() }
            start()
        }
        rotateAnimator?.duration = if (state == State.PROCESSING) 1100L else 6000L
    }

    @SuppressLint("DrawAllocation")
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return
        val cx = width / 2f
        val cy = height / 2f
        val baseRadius = minOf(width, height) / 2f * 0.62f
        val breathing = baseRadius * (1f + 0.06f * sin(pulsePhase * Math.PI).toFloat())

        if (lastRadius != breathing) {
            glow = RadialGradient(cx, cy, breathing * 1.8f,
                intArrayOf(Color.argb(90, 66, 133, 244), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
            sweep = SweepGradient(cx, cy, colors, null)
            lastRadius = breathing
        }
        glowPaint.shader = glow
        canvas.drawCircle(cx, cy, breathing * 1.8f, glowPaint)

        matrix.setRotate(rotation, cx, cy)
        sweep?.setLocalMatrix(matrix)
        corePaint.shader = sweep
        canvas.drawCircle(cx, cy, breathing, corePaint)

        canvas.drawCircle(cx, cy, breathing * 0.74f, discPaint)

        if (waveAmplitude > 0.01f) {
            wavePaint.color = Color.argb((180 * waveAmplitude).toInt(), 255, 255, 255)
            val bars = 24
            for (i in 0 until bars) {
                val angle = 2.0 * Math.PI * i / bars
                val wave = (0.5 + 0.5 * sin(rotation * 0.045 + i * 1.7)).toFloat()
                val r1 = breathing * 0.80f
                val r2 = breathing * (0.90f + 0.08f * wave * waveAmplitude)
                canvas.drawLine(
                    cx + r1 * cos(angle).toFloat(), cy + r1 * sin(angle).toFloat(),
                    cx + r2 * cos(angle).toFloat(), cy + r2 * sin(angle).toFloat(), wavePaint
                )
            }
        }
    }

    override fun onDetachedFromWindow() {
        pulseAnimator?.cancel(); rotateAnimator?.cancel(); ampAnimator?.cancel()
        pulseAnimator = null; rotateAnimator = null; ampAnimator = null
        super.onDetachedFromWindow()
    }
}

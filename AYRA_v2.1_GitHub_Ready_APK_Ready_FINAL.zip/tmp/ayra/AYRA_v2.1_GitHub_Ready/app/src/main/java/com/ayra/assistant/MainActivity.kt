package com.ayra.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognizerIntent
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.ayra.assistant.tools.ToolActionRouter
import com.ayra.assistant.ui.AyraBubbleController
import com.ayra.assistant.ui.AyraCalculatorDialog
import com.ayra.assistant.ui.AyraTransitionController
import com.ayra.assistant.utility.AyraUtilityState
import java.util.Date

class MainActivity : AppCompatActivity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var timeText: TextView
    private lateinit var statusText: TextView
    private lateinit var bubble: AyraBubbleController
    private lateinit var hud: com.ayra.assistant.ui.CircularHudView

    private val clockTick = object : Runnable {
        override fun run() {
            if (::timeText.isInitialized) timeText.text = AyraUtilityState.currentTime(Date())
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        bindViews()
        bindActions()
        handler.post(clockTick)
        AyraTransitionController.enter(findViewById(R.id.content))
    }

    private fun bindViews() {
        timeText = findViewById(R.id.txtTime)
        statusText = findViewById(R.id.txtStatus)
        bubble = findViewById(R.id.ayraBubble)
        hud = findViewById(R.id.hud)
        statusText.text = "READY"
    }

    private fun bindActions() {
        findViewById<View>(R.id.btnMic).setOnClickListener { startVoice() }
        findViewById<View>(R.id.btnSettings).setOnClickListener {
            ToolActionRouter.run(this, ToolActionRouter.Action.NETWORK)
        }
        findViewById<View>(R.id.btnShare).setOnClickListener {
            val share = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, "AYRA — ${AyraUtilityState.currentTime(Date())}")
            }
            startActivity(Intent.createChooser(share, "Share with"))
        }
        bubble.setOnActivateListener { active ->
            hud.listening = active
            statusText.text = if (active) "LISTENING" else "READY"
        }
        val toolHub = findViewById<com.ayra.assistant.ui.AyraToolHubView>(R.id.toolHub)
        toolHub.onCalculatorRequested = { AyraCalculatorDialog(this).show() }
        toolHub.onWeatherRequested = { statusText.text = "WEATHER" }
    }

    private fun startVoice() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_AUDIO)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Ask AYRA")
        }
        try {
            startActivityForResult(intent, REQUEST_VOICE)
        } catch (_: Exception) {
            statusText.text = "VOICE UNAVAILABLE"
        }
    }

    @Deprecated("Activity result API retained for Android 11 compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_VOICE) return
        statusText.text = if (resultCode == Activity.RESULT_OK) {
            val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (text.isNullOrBlank()) "READY" else "HEARD"
        } else "READY"
    }

    override fun onDestroy() {
        handler.removeCallbacks(clockTick)
        super.onDestroy()
    }

    companion object {
        private const val REQUEST_AUDIO = 2101
        private const val REQUEST_VOICE = 2102
    }
}

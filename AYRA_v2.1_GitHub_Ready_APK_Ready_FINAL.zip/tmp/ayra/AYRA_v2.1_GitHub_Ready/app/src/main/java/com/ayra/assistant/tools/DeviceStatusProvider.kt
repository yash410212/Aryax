package com.ayra.assistant.tools

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat

/** Lightweight, read-only device status snapshot for AYRA cards. */
class DeviceStatusProvider(private val context: Context) {
    data class Snapshot(
        val batteryPercent: Int,
        val charging: Boolean,
        val wifi: Boolean,
        val bluetooth: Boolean,
        val hotspot: Boolean,
        val internet: Boolean,
        val signalLevel: Int? // 0..4 when available
    )

    fun read(): Snapshot {
        val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val rawBattery = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val battery = if (rawBattery in 0..100) rawBattery else batteryFromBroadcast()
        val charging = context.registerReceiver(null, android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED))
            ?.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            ?.let { it == BatteryManager.BATTERY_STATUS_CHARGING || it == BatteryManager.BATTERY_STATUS_FULL }
            ?: false

        val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        val wifi = wifiManager?.isWifiEnabled == true

        val bluetooth = try {
            BluetoothAdapter.getDefaultAdapter()?.isEnabled == true
        } catch (_: SecurityException) {
            false
        }
        val connectivity = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = connectivity.activeNetwork
        val caps = network?.let { connectivity.getNetworkCapabilities(it) }
        val internet = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true

        // Android does not expose a reliable public hotspot-state API on all OEM builds.
        // Keep this conservative: false means "not confirmed", not necessarily "off".
        val hotspot = readHotspotStateConservatively(wifiManager)

        val signal = readSignalLevel()
        return Snapshot(battery, charging, wifi, bluetooth, hotspot, internet, signal)
    }

    private fun batteryFromBroadcast(): Int {
        val intent = context.registerReceiver(null, android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED))
            ?: return 0
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        return if (level >= 0 && scale > 0) ((level * 100f) / scale).toInt().coerceIn(0, 100) else 0
    }

    private fun readSignalLevel(): Int? {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return null
        }
        val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager ?: return null
        return try {
            @Suppress("DEPRECATION")
            tm.signalStrength?.level?.coerceIn(0, 4)
        } catch (_: SecurityException) { null }
    }

    private fun readHotspotStateConservatively(wifiManager: WifiManager?): Boolean {
        // Hidden APIs differ between Android/OEM versions; don't reflect into them.
        // Returning false avoids pretending that a restricted API is authoritative.
        return false
    }
}

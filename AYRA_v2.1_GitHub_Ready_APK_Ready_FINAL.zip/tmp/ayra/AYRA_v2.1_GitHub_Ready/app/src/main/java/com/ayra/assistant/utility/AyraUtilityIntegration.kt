package com.ayra.assistant.utility

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager

class AyraUtilityIntegration(context: Context) {
    private val appContext = context.applicationContext

    /** Returns 0..100, or -1 when no trustworthy battery value is available. */
    fun batteryPercent(): Int {
        val manager = appContext.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val direct = manager?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
        if (direct in 0..100) return direct
        val intent = appContext.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return -1
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        return if (level >= 0 && scale > 0) ((level * 100f) / scale).toInt().coerceIn(0, 100) else -1
    }
}

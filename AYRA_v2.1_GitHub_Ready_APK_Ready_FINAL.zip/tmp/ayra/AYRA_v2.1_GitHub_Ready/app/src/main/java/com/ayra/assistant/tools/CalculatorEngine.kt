package com.ayra.assistant.tools

import java.util.Locale

/** Small dependency-free calculator engine for the AYRA tool card. */
object CalculatorEngine {
    fun evaluate(raw: String): String {
        val input = raw.replace("×", "*").replace("÷", "/").replace("−", "-").replace(",", "").trim()
        if (input.isBlank()) return "0"
        return try {
            val result = Parser(input).parse()
            if (!result.isFinite()) "Error" else format(result)
        } catch (_: Exception) { "Error" }
    }

    private fun format(v: Double): String = if (v == v.toLong().toDouble()) v.toLong().toString()
    else String.format(Locale.US, "%.10f", v).trimEnd('0').trimEnd('.')

    private class Parser(private val s: String) {
        private var p = 0
        fun parse(): Double { val v = expression(); skip(); if (p != s.length) error("tail"); return v }
        private fun expression(): Double {
            var v = term()
            while (true) { skip(); v = when { eat('+') -> v + term(); eat('-') -> v - term(); else -> return v } }
        }
        private fun term(): Double {
            var v = factor()
            while (true) { skip(); v = when { eat('*') -> v * factor(); eat('/') -> v / factor(); else -> return v } }
        }
        private fun factor(): Double {
            skip(); if (eat('+')) return factor(); if (eat('-')) return -factor()
            if (eat('(')) { val v=expression(); if(!eat(')')) error(")"); return v }
            val start=p; while(p<s.length && (s[p].isDigit() || s[p]=='.')) p++
            if(start==p) error("number")
            return s.substring(start,p).toDouble()
        }
        private fun skip(){while(p<s.length&&s[p].isWhitespace())p++}
        private fun eat(c:Char):Boolean{skip();if(p<s.length&&s[p]==c){p++;return true};return false}
        private fun error(x:String):Nothing=throw IllegalArgumentException(x)
    }
}

package com.ayra.assistant.tools

import java.util.Locale

/** Fast, defensive fuzzy app-name matching. Pure Kotlin; no Android dependencies. */
object AppMatcher {
    data class MatchResult(val appName: String, val score: Double)

    fun findBestMatch(
        query: String,
        installedApps: List<String>,
        threshold: Double = 0.55
    ): String? {
        val q = normalize(query)
        if (q.isEmpty() || installedApps.isEmpty()) return null
        val minScore = threshold.coerceIn(0.0, 1.0)
        var best: MatchResult? = null
        for (app in installedApps) {
            if (app.isBlank()) continue
            val score = similarity(q, normalize(app))
            if (best == null || score > best.score) best = MatchResult(app, score)
        }
        return best?.takeIf { it.score >= minScore }?.appName
    }

    fun rankMatches(query: String, installedApps: List<String>, limit: Int = 3): List<MatchResult> {
        val q = normalize(query)
        if (q.isEmpty() || limit <= 0) return emptyList()
        return installedApps.asSequence()
            .filter { it.isNotBlank() }
            .map { MatchResult(it, similarity(q, normalize(it))) }
            .sortedByDescending { it.score }
            .take(limit)
            .toList()
    }

    private fun normalize(value: String): String =
        value.lowercase(Locale.ROOT)
            .filter { it.isLetterOrDigit() || it.isWhitespace() }
            .trim()

    private fun similarity(a: String, b: String): Double {
        if (a.isEmpty() || b.isEmpty()) return if (a == b) 1.0 else 0.0
        if (a == b) return 1.0
        if (b.startsWith(a) || a.startsWith(b)) return 0.9
        if (b.contains(a) || a.contains(b)) return 0.8
        val maxLen = maxOf(a.length, b.length)
        return 1.0 - levenshtein(a, b).toDouble() / maxLen
    }

    /** O(min(a,b)) memory instead of allocating a 2D matrix for every comparison. */
    private fun levenshtein(a: String, b: String): Int {
        var left = a
        var right = b
        if (left.length > right.length) {
            val tmp = left; left = right; right = tmp
        }
        var previous = IntArray(left.length + 1) { it }
        var current = IntArray(left.length + 1)
        for (j in 1..right.length) {
            current[0] = j
            for (i in 1..left.length) {
                val cost = if (left[i - 1] == right[j - 1]) 0 else 1
                current[i] = minOf(current[i - 1] + 1, previous[i] + 1, previous[i - 1] + cost)
            }
            val tmp = previous; previous = current; current = tmp
        }
        return previous[left.length]
    }

}

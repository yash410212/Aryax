package com.ayra.assistant.tools

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent

object AyraAppShortcutProvider {
    data class Shortcut(val title: String, val packages: List<String>)

    private val shortcuts = listOf(
        Shortcut("YouTube", listOf("com.google.android.youtube")),
        Shortcut("Chrome", listOf("com.android.chrome", "com.google.android.apps.chrome")),
        Shortcut("Settings", listOf("com.android.settings"))
    )

    fun available(context: Context): List<Shortcut> = shortcuts.filter { findIntent(context, it) != null }

    fun launch(context: Context, shortcut: Shortcut): Boolean {
        val intent = findIntent(context, shortcut) ?: return false
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent); true
        } catch (_: ActivityNotFoundException) { false }
        catch (_: SecurityException) { false }
        catch (_: RuntimeException) { false }
    }

    private fun findIntent(context: Context, shortcut: Shortcut): Intent? {
        val pm = context.packageManager
        for (pkg in shortcut.packages) {
            try { pm.getLaunchIntentForPackage(pkg)?.let { return it } } catch (_: RuntimeException) { }
        }
        return null
    }
}

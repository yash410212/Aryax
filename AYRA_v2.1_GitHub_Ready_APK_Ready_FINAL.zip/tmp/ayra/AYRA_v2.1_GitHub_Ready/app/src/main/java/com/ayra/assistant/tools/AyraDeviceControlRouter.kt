package com.ayra.assistant.tools

import android.bluetooth.BluetoothAdapter
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.provider.Settings

object AyraDeviceControlRouter {
    enum class Control { WIFI, BLUETOOTH, HOTSPOT, AIRPLANE, LOCATION, NFC, SOUND, BATTERY }

    fun open(context: Context, control: Control): Boolean {
        val app = context.applicationContext
        val primary = when (control) {
            Control.WIFI -> Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
            Control.BLUETOOTH -> Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            Control.HOTSPOT -> Intent(Settings.ACTION_WIRELESS_SETTINGS)
            Control.AIRPLANE -> Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)
            Control.LOCATION -> Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
            Control.NFC -> Intent(Settings.ACTION_NFC_SETTINGS)
            Control.SOUND -> Intent(Settings.ACTION_SOUND_SETTINGS)
            Control.BATTERY -> Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
        }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        return try {
            app.startActivity(primary); true
        } catch (_: ActivityNotFoundException) {
            openFallback(app)
        } catch (_: SecurityException) {
            false
        } catch (_: RuntimeException) {
            false
        }
    }

    private fun openFallback(context: Context): Boolean = try {
        context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (_: Exception) { false }
}

package com.ayra.assistant.quicksettings

import android.content.Intent
import android.graphics.drawable.Icon
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.ayra.assistant.MainActivity
import com.ayra.assistant.R

class AyraQuickSettingsTileService : TileService() {
    override fun onStartListening() {
        super.onStartListening()
        qsTile?.let { tile ->
            tile.label = "AYRA"
            tile.contentDescription = "Open AYRA"
            tile.icon = Icon.createWithResource(this, R.drawable.ic_bubble_idle)
            tile.state = Tile.STATE_INACTIVE
            tile.updateTile()
        }
    }

    override fun onClick() {
        super.onClick()
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        try { startActivityAndCollapse(intent) } catch (_: RuntimeException) { startActivity(intent) }
    }
}

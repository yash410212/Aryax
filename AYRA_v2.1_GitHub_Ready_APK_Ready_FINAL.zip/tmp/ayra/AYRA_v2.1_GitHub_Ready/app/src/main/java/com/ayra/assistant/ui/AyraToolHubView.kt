package com.ayra.assistant.ui

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import com.ayra.assistant.R
import com.ayra.assistant.tools.CalculatorEngine
import com.ayra.assistant.tools.DeviceStatusProvider
import com.ayra.assistant.tools.ToolActionRouter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Drop-in tool dashboard for AYRA. Designed around compact cards rather than
 * giant buttons: status first, quick controls second, utilities third.
 */
class AyraToolHubView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : ConstraintLayout(context, attrs) {
    private val status = DeviceStatusProvider(context)
    private val handler = Handler(Looper.getMainLooper())
    private val timeFormat = SimpleDateFormat("h:mm a", Locale.getDefault())
    private val dateFormat = SimpleDateFormat("EEE, d MMM", Locale.getDefault())
    private val updateClock = object : Runnable { override fun run(){ updateTime(); handler.postDelayed(this, 1000) } }
    var onCalculatorRequested: (() -> Unit)? = null
    var onWeatherRequested: (() -> Unit)? = null

    init {
        LayoutInflater.from(context).inflate(R.layout.view_ayra_tool_hub, this, true)
        bindLabels()
        bindActions()
        refresh()
        handler.post(updateClock)
    }

    private fun bindLabels() {
        findViewById<View>(R.id.toolWifi).findViewById<TextView>(R.id.actionTitle).text = "Wi‑Fi"
        findViewById<View>(R.id.toolWifi).findViewById<TextView>(R.id.actionHint).text = "Internet panel"
        findViewById<View>(R.id.toolBluetooth).findViewById<TextView>(R.id.actionTitle).text = "Bluetooth"
        findViewById<View>(R.id.toolBluetooth).findViewById<TextView>(R.id.actionHint).text = "Pair & connect"
        findViewById<View>(R.id.toolHotspot).findViewById<TextView>(R.id.actionTitle).text = "Hotspot"
        findViewById<View>(R.id.toolHotspot).findViewById<TextView>(R.id.actionHint).text = "System control"
        findViewById<View>(R.id.toolBattery).findViewById<TextView>(R.id.actionTitle).text = "Battery"
        findViewById<View>(R.id.toolBattery).findViewById<TextView>(R.id.actionHint).text = "Power settings"
        findViewById<View>(R.id.toolCalculator).findViewById<TextView>(R.id.utilityTitle).text = "Calculator"
        findViewById<View>(R.id.toolCalculator).findViewById<TextView>(R.id.utilityHint).text = "Fast calculations"
        findViewById<View>(R.id.toolWeather).findViewById<TextView>(R.id.utilityTitle).text = "Weather"
        findViewById<View>(R.id.toolWeather).findViewById<TextView>(R.id.utilityHint).text = "Live forecast"
    }

    private fun bindActions() {
        findViewById<View>(R.id.toolWifi).setOnClickListener { ToolActionRouter.run(context, ToolActionRouter.Action.WIFI); refresh() }
        findViewById<View>(R.id.toolBluetooth).setOnClickListener { ToolActionRouter.run(context, ToolActionRouter.Action.BLUETOOTH); refresh() }
        findViewById<View>(R.id.toolHotspot).setOnClickListener { ToolActionRouter.run(context, ToolActionRouter.Action.HOTSPOT); refresh() }
        findViewById<View>(R.id.toolBattery).setOnClickListener { ToolActionRouter.run(context, ToolActionRouter.Action.BATTERY) }
        findViewById<View>(R.id.toolNetwork).setOnClickListener { ToolActionRouter.run(context, ToolActionRouter.Action.NETWORK) }
        findViewById<View>(R.id.toolCalculator).setOnClickListener { onCalculatorRequested?.invoke() ?: AyraCalculatorDialog(context).show() }
        findViewById<View>(R.id.toolWeather).setOnClickListener { onWeatherRequested?.invoke() }
    }

    fun refresh() {
        val s = status.read()
        findViewById<View>(R.id.statusBattery).findViewById<TextView>(R.id.chipValue).text = "${s.batteryPercent}%${if(s.charging) " • Charging" else ""}"
        findViewById<View>(R.id.statusWifi).findViewById<TextView>(R.id.chipValue).text = if (s.wifi) "Connected" else "Off"
        findViewById<View>(R.id.statusBluetooth).findViewById<TextView>(R.id.chipValue).text = if (s.bluetooth) "On" else "Off"
        findViewById<View>(R.id.statusInternet).findViewById<TextView>(R.id.chipValue).text = if (s.internet) "Online" else "Offline"
        findViewById<View>(R.id.statusSignal).findViewById<TextView>(R.id.chipValue).text = s.signalLevel?.let { "${it}/4" } ?: "—"
        findViewById<View>(R.id.statusHotspot).findViewById<TextView>(R.id.chipValue).text = if (s.hotspot) "On" else "Not confirmed"
    }

    private fun updateTime() {
        findViewById<TextView>(R.id.timeValue).text = timeFormat.format(Date())
        findViewById<TextView>(R.id.dateValue).text = dateFormat.format(Date())
    }


    override fun onDetachedFromWindow() { handler.removeCallbacks(updateClock); super.onDetachedFromWindow() }
}

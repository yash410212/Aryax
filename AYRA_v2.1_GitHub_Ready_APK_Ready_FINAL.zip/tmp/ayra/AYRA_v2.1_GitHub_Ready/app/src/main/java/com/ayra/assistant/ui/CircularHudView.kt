package com.ayra.assistant.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

/**
 * JARVIS/Iron-Man style circular HUD for AYRA's main screen.
 * Draws: outer tick ring, mid arc ring (animates while listening),
 * inner grid disc, and lets you overlay the clock/status text on top
 * via normal TextViews positioned at the view's center in your XML —
 * this view only draws the dial graphics.
 *
 * Usage in XML:
 *   <com.ayra.assistant.ui.CircularHudView
 *       android:id="@+id/hud"
 *       android:layout_width="300dp"
 *       android:layout_height="300dp" />
 *
 * In code:
 *   hud.listening = true   // when mic is active, animates the arc sweep
 *   hud.accentColor = Color.parseColor("#2DD4BF")
 */
class CircularHudView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var accentColor: Int = Color.parseColor("#2DD4BF")
        set(value) { field = value; invalidate() }

    var listening: Boolean = false
        set(value) {
            field = value
            if (value) startSweep() else stopSweep()
        }

    private val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }
    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 6f
        strokeCap = Paint.Cap.ROUND
    }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1f
    }

    private var sweepAngle = 0f
    private var idleRotation = 0f
    private var sweepAnimator: ValueAnimator? = null
    private val idleAnimator = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 20000
        repeatCount = ValueAnimator.INFINITE
    }

    init {
        idleAnimator.addUpdateListener { idleRotation = it.animatedValue as Float; invalidate() }
        idleAnimator.start()
    }

    private fun startSweep() {
        sweepAnimator?.cancel()
        sweepAnimator = ValueAnimator.ofFloat(0f, 100f).apply {
            duration = 2200
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener { sweepAngle = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    private fun stopSweep() {
        sweepAnimator?.cancel()
        sweepAngle = 0f
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val radius = minOf(width, height) / 2f * 0.92f

        // 1. Outer tick marks (clock-face style)
        tickPaint.color = Color.argb(160, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor))
        for (i in 0 until 72) {
            val angle = Math.toRadians((i * 5).toDouble())
            val isMajor = i % 6 == 0
            val outerR = radius
            val innerR = radius - if (isMajor) 22f else 10f
            val x1 = cx + outerR * cos(angle).toFloat()
            val y1 = cy + outerR * sin(angle).toFloat()
            val x2 = cx + innerR * cos(angle).toFloat()
            val y2 = cy + innerR * sin(angle).toFloat()
            tickPaint.strokeWidth = if (isMajor) 3.5f else 2f
            canvas.drawLine(x1, y1, x2, y2, tickPaint)
        }

        // 2. Mid static ring
        ringPaint.color = Color.argb(90, 150, 170, 180)
        canvas.drawCircle(cx, cy, radius * 0.78f, ringPaint)

        // 3. Rotating accent arc segments (always slowly spinning, like image reference)
        arcPaint.color = accentColor
        val rect = RectF(cx - radius * 0.86f, cy - radius * 0.86f, cx + radius * 0.86f, cy + radius * 0.86f)
        canvas.drawArc(rect, idleRotation, 40f, false, arcPaint)
        canvas.drawArc(rect, idleRotation + 160f, 25f, false, arcPaint)

        // 4. Listening sweep — brighter, faster arc that chases around when mic is on
        if (listening) {
            arcPaint.color = Color.WHITE
            arcPaint.strokeWidth = 8f
            canvas.drawArc(rect, sweepAngle * 3.6f, 50f, false, arcPaint)
            arcPaint.strokeWidth = 6f
        }

        // 5. Inner triangulated grid disc (subtle, decorative)
        gridPaint.color = Color.argb(40, 120, 200, 210)
        val gridR = radius * 0.6f
        for (i in 0 until 12) {
            val angle = Math.toRadians((i * 30).toDouble())
            val x = cx + gridR * cos(angle).toFloat()
            val y = cy + gridR * sin(angle).toFloat()
            canvas.drawLine(cx, cy, x, y, gridPaint)
        }
        canvas.drawCircle(cx, cy, gridR, gridPaint)
        canvas.drawCircle(cx, cy, gridR * 0.6f, gridPaint)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        sweepAnimator?.cancel()
        idleAnimator.cancel()
    }
}

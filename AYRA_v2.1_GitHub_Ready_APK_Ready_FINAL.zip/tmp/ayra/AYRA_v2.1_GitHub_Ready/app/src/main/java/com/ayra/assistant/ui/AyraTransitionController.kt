package com.ayra.assistant.ui

import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator

/** Shared transitions for cards/screens. Keeps AYRA motion consistent. */
object AyraTransitionController {
    fun enter(container: ViewGroup) {
        for (i in 0 until container.childCount) {
            val child = container.getChildAt(i)
            AyraMotion.reveal(child, i * 28L)
        }
    }

    fun select(view: View, selected: Boolean) {
        view.animate()
            .scaleX(if (selected) .985f else 1f)
            .scaleY(if (selected) .985f else 1f)
            .alpha(if (selected) 1f else .78f)
            .setDuration(160L)
            .setInterpolator(DecelerateInterpolator())
            .start()
        view.isSelected = selected
    }
}

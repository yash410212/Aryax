package com.ayra.assistant.ui

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.ayra.assistant.R
import com.ayra.assistant.tools.AyraAppShortcutProvider
import com.ayra.assistant.tools.AyraDeviceControlRouter

/** Compact control surface. It routes restricted actions to Android settings rather than faking toggles. */
class AyraDeviceControlsView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : LinearLayout(context, attrs) {
    init {
        orientation = VERTICAL
        LayoutInflater.from(context).inflate(R.layout.view_ayra_device_controls, this, true)
        bindControls()
        bindApps()
    }

    private fun bindControls() {
        bind(R.id.controlWifi, "Wi-Fi", "Internet & networks", AyraDeviceControlRouter.Control.WIFI)
        bind(R.id.controlBluetooth, "Bluetooth", "Pair & connect", AyraDeviceControlRouter.Control.BLUETOOTH)
        bind(R.id.controlHotspot, "Hotspot", "System network settings", AyraDeviceControlRouter.Control.HOTSPOT)
        bind(R.id.controlAirplane, "Airplane mode", "System control", AyraDeviceControlRouter.Control.AIRPLANE)
        bind(R.id.controlLocation, "Location", "Location services", AyraDeviceControlRouter.Control.LOCATION)
        bind(R.id.controlNfc, "NFC", "Contactless settings", AyraDeviceControlRouter.Control.NFC)
        bind(R.id.controlSound, "Sound", "Volume & sound settings", AyraDeviceControlRouter.Control.SOUND)
        bind(R.id.controlBattery, "Battery", "Power & battery settings", AyraDeviceControlRouter.Control.BATTERY)
    }

    private fun bind(id: Int, title: String, hint: String, control: AyraDeviceControlRouter.Control) {
        val row = findViewById<View>(id)
        row.findViewById<TextView>(R.id.controlTitle).text = title
        row.findViewById<TextView>(R.id.controlHint).text = hint
        row.setOnClickListener { AyraDeviceControlRouter.open(context, control) }
    }

    private fun bindApps() {
        val container = findViewById<LinearLayout>(R.id.appShortcuts)
        container.removeAllViews()
        AyraAppShortcutProvider.available(context).forEach { shortcut ->
            val row = LayoutInflater.from(context).inflate(R.layout.item_app_shortcut, container, false)
            row.findViewById<TextView>(R.id.appTitle).text = shortcut.title
            row.findViewById<TextView>(R.id.appHint).text = "Open app"
            row.setOnClickListener { AyraAppShortcutProvider.launch(context, shortcut) }
            container.addView(row)
        }
        findViewById<TextView>(R.id.appEmpty).visibility = if (container.childCount == 0) View.VISIBLE else View.GONE
    }
}

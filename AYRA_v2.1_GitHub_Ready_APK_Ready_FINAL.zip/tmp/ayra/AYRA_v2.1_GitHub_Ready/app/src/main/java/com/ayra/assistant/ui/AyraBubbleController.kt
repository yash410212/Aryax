package com.ayra.assistant.ui

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import com.ayra.assistant.R

/**
 * Wraps the two bubble visuals AYRA needs:
 *   - idle icon  -> the static purple flower logo (ic_bubble_idle)
 *   - active orb -> the animated Gemini-style FloatingBubbleView from Part 1
 *
 * Tapping the bubble crossfades + scales from one to the other. Add THIS
 * view (not FloatingBubbleView directly) as the content view of your
 * overlay window in BackgroundAssistantService.
 *
 * Usage in BackgroundAssistantService:
 *   val bubble = AyraBubbleController(context)
 *   windowManager.addView(bubble, layoutParams)
 *   bubble.setOnActivateListener { activating ->
 *       if (activating) startListening() else stopListening()
 *   }
 *
 * When you want to reflect recognizer state once already active, call
 * bubble.setOrbState(FloatingBubbleView.State.LISTENING / .PROCESSING / .IDLE)
 */
class AyraBubbleController @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    private val idleIcon: ImageView
    private val activeOrb: FloatingBubbleView
    private var isActive = false
    private var onActivateListener: ((Boolean) -> Unit)? = null

    init {
        LayoutInflater.from(context).inflate(R.layout.view_ayra_bubble, this, true)
        idleIcon = findViewById(R.id.imgBubbleIdle)
        activeOrb = findViewById(R.id.orbBubbleActive)

        activeOrb.visibility = View.GONE
        activeOrb.alpha = 0f

        setOnClickListener { toggle() }
    }

    /** Programmatically flip idle <-> active with the same animation the tap uses. */
    fun toggle() {
        isActive = !isActive
        if (isActive) activate() else deactivate()
        onActivateListener?.invoke(isActive)
    }

    /** Once active, drive the orb's own listening/processing animation. */
    fun setOrbState(state: FloatingBubbleView.State) {
        activeOrb.state = state
    }

    fun setOnActivateListener(listener: ((Boolean) -> Unit)?) {
        onActivateListener = listener
    }

    private fun activate() {
        activeOrb.visibility = View.VISIBLE
        activeOrb.state = FloatingBubbleView.State.LISTENING

        val fadeOutIcon = ObjectAnimator.ofFloat(idleIcon, ALPHA, 1f, 0f)
        val shrinkIcon = ObjectAnimator.ofFloat(idleIcon, SCALE_X, 1f, 0.6f)
        val shrinkIconY = ObjectAnimator.ofFloat(idleIcon, SCALE_Y, 1f, 0.6f)

        val fadeInOrb = ObjectAnimator.ofFloat(activeOrb, ALPHA, 0f, 1f)
        val growOrb = ObjectAnimator.ofFloat(activeOrb, SCALE_X, 0.6f, 1f)
        val growOrbY = ObjectAnimator.ofFloat(activeOrb, SCALE_Y, 0.6f, 1f)

        AnimatorSet().apply {
            duration = 260
            playTogether(fadeOutIcon, shrinkIcon, shrinkIconY, fadeInOrb, growOrb, growOrbY)
            start()
        }.also {
            idleIcon.postDelayed({ idleIcon.visibility = View.GONE }, 260)
        }
    }

    private fun deactivate() {
        activeOrb.state = FloatingBubbleView.State.IDLE
        idleIcon.visibility = View.VISIBLE

        val fadeInIcon = ObjectAnimator.ofFloat(idleIcon, ALPHA, 0f, 1f)
        val growIcon = ObjectAnimator.ofFloat(idleIcon, SCALE_X, 0.6f, 1f)
        val growIconY = ObjectAnimator.ofFloat(idleIcon, SCALE_Y, 0.6f, 1f)

        val fadeOutOrb = ObjectAnimator.ofFloat(activeOrb, ALPHA, 1f, 0f)
        val shrinkOrb = ObjectAnimator.ofFloat(activeOrb, SCALE_X, 1f, 0.6f)
        val shrinkOrbY = ObjectAnimator.ofFloat(activeOrb, SCALE_Y, 1f, 0.6f)

        AnimatorSet().apply {
            duration = 260
            playTogether(fadeInIcon, growIcon, growIconY, fadeOutOrb, shrinkOrb, shrinkOrbY)
            start()
        }.also {
            activeOrb.postDelayed({ activeOrb.visibility = View.GONE }, 260)
        }
    }
}

# AYRA currently ships without code shrinking. Keep this file for future R8 rules.

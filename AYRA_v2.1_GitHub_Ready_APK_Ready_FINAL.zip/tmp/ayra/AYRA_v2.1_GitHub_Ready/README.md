# AYRA v2.1 — GitHub Ready Android Project

This is the merged, build-oriented AYRA v2.1 project prepared from Parts 1–10 and the later polish/deep-fix work.

## Build
- Android Gradle Plugin: 8.6.1
- Gradle: 8.7 (GitHub Actions provisions it)
- Kotlin: 2.0.21
- Compile SDK: 35
- Target SDK: 35
- Minimum SDK: 23
- Java: 17

### GitHub Actions
Push this folder as the repository root. `.github/workflows/build.yml` builds both Debug and Release APKs and uploads them as an artifact.

No ZIP extraction is required in Actions because this archive is already the actual Android project root. If you instead commit this ZIP as a file, Actions cannot build its contents automatically unless you add a separate extraction step; the recommended setup is to extract this archive into the repository root.

## Included functionality
- AYRA HUD and animated bubble
- Calculator
- Device status cards
- Android system-routed device controls
- App shortcuts with Android 11 package visibility declarations
- Quick Settings tile
- Time/date utilities
- Shared lightweight animations/transitions

## Compatibility notes
Android restricts silent Wi-Fi/hotspot changes for ordinary apps. AYRA therefore routes restricted controls to the appropriate system UI instead of falsely claiming a toggle succeeded.

Signal status is permission-aware. Battery status has a broadcast fallback when the direct capacity property is unavailable.

## Verification performed before packaging
- XML parsing check
- Duplicate top-level Kotlin class-name check
- Resource/reference audit
- Manifest/package visibility review
- Gradle project structure review
- Android 11+ restricted-control review
